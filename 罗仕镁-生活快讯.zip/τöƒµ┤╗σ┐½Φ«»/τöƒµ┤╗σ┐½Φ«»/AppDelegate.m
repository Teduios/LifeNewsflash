//
//  AppDelegate.m
//  生活快讯
//
//  Created by LuoShimei on 15/10/21.
//  Copyright © 2015年 Apple. All rights reserved.
//

#import "AppDelegate.h"
#import "AppDelegate+Category.h"
//#import "UMSocial.h"
#import "NewsNetManager.h"
#import "NewsTabBarController.h"
#import "NewsViewController.h"
#import "NewsNavigationController.h"
#import "NewsDetailNetManager.h"
#import "VideoSidNetManager.h"
#import "NewsPhotoSetNetManager.h"

@interface AppDelegate ()

@end

@implementation AppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.
    [self initializeWithApplication:application];
    //[UMSocialData setAppKey:@"563ad05167e58e3016000ff8"];
    
    self.window.rootViewController = self.tabBarViewController;
    [self configGlobalUIStyle];
    return YES;
}

/** 配置全局UI的样式 */
- (void)configGlobalUIStyle{
    /** 设置电池条的颜色为白色 */
    [[UINavigationBar appearance] setBarStyle:UIBarStyleBlack];
    /**设置导航栏的背景颜色*/
    [UINavigationBar appearance].barTintColor = [UIColor colorWithRed:73/255.0 green:178/255.0 blue:133/255.0 alpha:1];
    /** 导航栏不透明 */
    [[UINavigationBar appearance] setTranslucent:NO];
    /** 配置导航栏题目的样式 */
    [[UINavigationBar appearance] setTitleTextAttributes:@{NSFontAttributeName:[UIFont flatFontOfSize:17], NSForegroundColorAttributeName: [UIColor whiteColor]}];
   
    [UITabBar appearance].backgroundColor = [UIColor whiteColor];
}

/** 代码重构:用代码把功能实现以后，考虑代码结构如何编写可以更加方便后期维护 */
- (UIWindow *)window{
    if (!_window) {
        _window = [[UIWindow alloc] initWithFrame:[UIScreen mainScreen].bounds];
        [_window makeKeyAndVisible];
    }
    return _window;
}

- (UITabBarController *)tabBarViewController{
    if (!_tabBarViewController) {
        _tabBarViewController = [[NewsTabBarController alloc] init];        
    }
    return _tabBarViewController;
}


@end
