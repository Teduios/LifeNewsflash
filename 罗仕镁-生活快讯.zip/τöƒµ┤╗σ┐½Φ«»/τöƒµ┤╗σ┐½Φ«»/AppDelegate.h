//
//  AppDelegate.h
//  生活快讯
//
//  Created by LuoShimei on 15/10/21.
//  Copyright © 2015年 Apple. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;
@property (nonatomic,strong) UITabBarController *tabBarViewController;
@property(nonatomic,getter=isOnLine) BOOL onLine; //网络状态
@end

